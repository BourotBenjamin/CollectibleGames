<?

       define('IN_PHPBB', true);
    $phpbb_root_path = './phpbb3/';
    $phpEx = substr(strrchr(__FILE__, '.'), 1);
    include($phpbb_root_path . 'site_common.php');
     
    // Start session management
    $user->session_begin();
    $auth->acl($user->data);
    $user->setup();
    $username = $_POST['username'];
    $password = $_POST['password'];
	$result = $auth->login($username, $password);
?>