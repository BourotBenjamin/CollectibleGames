<?php exit; ?>
1431199121
225
a:6:{s:4:"name";s:10:"Darky Gray";s:9:"copyright";s:39:"&copy; darky 2011-12 www.foruminfopc.fr";s:7:"version";s:6:"3.0.12";s:17:"template_bitfield";s:4:"lNg=";s:12:"inherit_from";s:9:"prosilver";s:8:"filetime";i:1399654321;}