<?php exit; ?>
1431199121
181
a:5:{s:4:"name";s:10:"Darky Gray";s:9:"copyright";s:41:"&copy; darky 2011-12 - www.foruminfopc.fr";s:7:"version";s:6:"3.0.12";s:14:"parse_css_file";b:1;s:8:"filetime";i:1399654343;}