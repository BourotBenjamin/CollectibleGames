Zoombox
=============

Zoombox is an easy to use Javascript class that allow you to overlay images and videos on the current page.

To see more information on how to use and install zoombox please visite : http://grafikart.fr/zoombox