<?php

namespace CollectibleGames\DatabaseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CollectibleGamesDatabaseBundle extends Bundle
{
}
