<?php

namespace CollectibleGames\CollectionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CollectibleGamesCollectionBundle extends Bundle
{
}
